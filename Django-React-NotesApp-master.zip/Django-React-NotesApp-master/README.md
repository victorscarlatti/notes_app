hello

this is a note app with django e react